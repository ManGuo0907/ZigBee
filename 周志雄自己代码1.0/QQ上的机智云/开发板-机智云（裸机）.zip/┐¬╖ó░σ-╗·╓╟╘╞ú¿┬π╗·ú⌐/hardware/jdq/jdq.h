#ifndef  _JDQ_H
#define  _JDQ_H

#include "stm32f10x.h"
#include "sys.h"


#define jdq1 PBout(12)

void jdq_init(void);

#endif

