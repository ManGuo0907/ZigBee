#ifndef _USATR2_H
#define _USATR2_H

#include "stm32f10x.h"


void usart2_init(u32 bound);

#endif

